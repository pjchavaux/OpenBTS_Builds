typedef unsigned  char   u8;
typedef unsigned short  u16;
typedef unsigned   int  u32;

void A53_GSM( u8 *key, int klen, int count, u8 *block1, u8 *block2 );
