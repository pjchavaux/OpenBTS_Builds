select name, rand, sres, ki, kc from sip_buddies;
